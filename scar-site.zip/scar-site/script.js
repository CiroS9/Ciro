// --- Mobile menu ---
const btn = document.querySelector('.hamburger');
const menu = document.getElementById('menu-mobile');

if (btn && menu) {
  btn.addEventListener('click', () => {
    const isOpen = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!isOpen));
    menu.hidden = isOpen;
  });

  // Close menu when clicking a link
  menu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      btn.setAttribute('aria-expanded', 'false');
      menu.hidden = true;
    });
  });
}

// --- Footer year ---
document.getElementById('year').textContent = new Date().getFullYear();

// --- Quick config (replace with your real contacts) ---
const PHONE = '+390000000000';
const EMAIL = 'info@esempio.it';
const WA_NUMBER = '+390000000000'; // include country code
const WA_TEXT = encodeURIComponent('Ciao! Vorrei informazioni / una consulenza per un’auto.');

const telLink = document.getElementById('telLink');
const mailLink = document.getElementById('mailLink');
const waLink = document.getElementById('waLink');
const waLink2 = document.getElementById('waLink2');

if (telLink) { telLink.href = `tel:${PHONE}`; telLink.querySelector('span').textContent = PHONE; }
if (mailLink) { mailLink.href = `mailto:${EMAIL}`; mailLink.querySelector('span').textContent = EMAIL; }

const waHref = `https://wa.me/${WA_NUMBER.replace(/\D/g,'')}?text=${WA_TEXT}`;
if (waLink) waLink.href = waHref;
if (waLink2) waLink2.href = waHref;
